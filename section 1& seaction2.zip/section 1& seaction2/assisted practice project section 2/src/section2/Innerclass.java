package section2;

public class Innerclass {
	
	
	private String msg="Happy Birthday";

	 void display(){  
		 class Inner{  
			 void msg(){
				 System.out.println(msg);
			 }  
	  }  
		 Inner l=new Inner();  
		  l.msg();  
		 }  

		 
		public static void main(String[] args) {
			Innerclass  ob=new Innerclass ();  
			ob.display();  
			}
		}

