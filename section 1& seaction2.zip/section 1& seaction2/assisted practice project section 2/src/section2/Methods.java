package section2;

public class Methods {
	
	
		  public int addNumbers(int x, int y) {
		    int sum = x + y;
		    return sum;
		  }
		  public static void main(String[] args) {
		    int n1 = 5;
		    int n2 = 2;
		    Methods obj = new Methods();
		    int result = obj.addNumbers(n1, n2);
		    System.out.println("Sum is: " + result);
		  }
		}

