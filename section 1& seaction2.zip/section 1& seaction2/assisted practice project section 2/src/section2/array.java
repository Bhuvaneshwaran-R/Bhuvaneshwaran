package section2;

public class array {
	

		public static void main(String[] args) {

		//single-dimensional array
		int a[]= {11,22,33,44,55};
		for(int i=0;i<5;i++) {
		System.out.println("Elements of array a: "+a[i]);
		}


		//multidimensional array
		int[][] b = {
		            {2, 4, 6, 8}, 
		            {3, 6, 9} };
		      
		      System.out.println("\nLength of row 2: " + b[1].length);
		      }
		}

