package practiceproject2;
import java.util.ArrayList;
import java.util.Scanner;
public class ValidationEmail {
	public static void main(String[] args) {
			Scanner input = new Scanner(System.in);
			ArrayList<String> mail = new ArrayList<String>();
			mail.add("yuvaraj@gmail.com");
			mail.add("deepan@gmail.com");
			mail.add("saranya@gmail.com");
			mail.add("abishek@gmail.com");
			mail.add("dhaya@gmail.com");
			System.out.println("ENTER USER EMAIL ID:");
			String userId = input.nextLine();
			//checks user mail id and shows found or not
				if (mail.contains(userId)) {
					System.out.println();
					System.out.println("Email ID " + userId + " found");
				} 
				else {
					System.out.println("Email ID " + userId + " Not found");

				}
			}
		}

