package section3;

public class lamp {
	
		  boolean isOn;
		  void turnOn() {
		    isOn = true;
		    System.out.println("Light on? " + isOn);

		  }
		  void turnOff() {
		    isOn = false;
		    System.out.println("Light on? " + isOn);
		  }
		}

		class Main {
		  public static void main(String[] args) {
		    lamp led = new lamp();
		    lamp halogen = new lamp();
		    led.turnOn();
		    halogen.turnOff();
		  }
		}

